﻿using System;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            //input from the user
            Console.Write("Enter number 1: ");
            int numberOne = int.Parse(Console.ReadLine());
            Console.Write("Enter number 2: ");
            int numberTwo = int.Parse(Console.ReadLine());
            Console.Write("Enter operator(+ - * ): ");
            char inputOperator = char.Parse(Console.ReadLine());
            //using space 
            Console.WriteLine();
            

            //process using switch rather than if else
            switch (inputOperator)
            {
                case '+':
                    Console.WriteLine($"result = {numberOne + numberTwo}"); 
                    break;
                case '-':
                    Console.WriteLine($"result = {numberOne - numberTwo}");
                    break;
                case '*':
                    Console.WriteLine($"result = {numberOne * numberTwo}");
                    break;
                default:
                    Console.WriteLine("Invalid operator! ");
                    break;
            }
            Console.ReadKey();

        }
    }
}
