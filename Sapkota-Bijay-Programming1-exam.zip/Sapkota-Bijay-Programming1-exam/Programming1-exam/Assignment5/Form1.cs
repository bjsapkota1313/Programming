﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculatePrice_Click(object sender, EventArgs e)
        {
            //declraing constant term 
            const double Discount = 0.2;
            const double PriceNoTimeToDie = 12.65;
            const double PriceTheFather = 12.00;
            const double PriceAnneFrank = 11.00;
            
            

            int inputAge = int .Parse(textBox1.Text);
            if (rdoBtnNoTimeToDie.Checked)
            {
                if (inputAge > 65)
                {
                    lblOutputPrice.Text =$"{(PriceNoTimeToDie -(PriceNoTimeToDie * Discount)):0.00}".ToString();
                }
                else
                {
                    lblOutputPrice.Text = $"{PriceNoTimeToDie}" .ToString();
                }
            }
            else if(rdoBtnTheFather.Checked)
            {
                if (inputAge > 65)
                {
                    lblOutputPrice.Text = $"{(PriceTheFather-(PriceTheFather * Discount)):0.00}".ToString();
                }
                else
                {
                    lblOutputPrice.Text = $"{PriceTheFather:0.00}".ToString();
                }
            }
            else
            {
                if (inputAge > 65)
                {
                    lblOutputPrice.Text = $"{(PriceAnneFrank - (PriceAnneFrank * Discount)):0.00}".ToString();
                }
                else
                {
                    lblOutputPrice.Text = $"{PriceAnneFrank:0.00}".ToString();
                }
            }
        }
    }
}
