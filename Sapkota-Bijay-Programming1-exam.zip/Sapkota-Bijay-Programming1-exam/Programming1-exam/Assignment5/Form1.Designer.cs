﻿
namespace Assignment5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblage = new System.Windows.Forms.Label();
            this.lblMovie = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblOutputPrice = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.rdoBtnNoTimeToDie = new System.Windows.Forms.RadioButton();
            this.rdoBtnTheFather = new System.Windows.Forms.RadioButton();
            this.rdoBtnAnneFrank = new System.Windows.Forms.RadioButton();
            this.btnCalculatePrice = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblage
            // 
            this.lblage.AutoSize = true;
            this.lblage.Location = new System.Drawing.Point(61, 82);
            this.lblage.Name = "lblage";
            this.lblage.Size = new System.Drawing.Size(68, 32);
            this.lblage.TabIndex = 0;
            this.lblage.Text = "Age: ";
            // 
            // lblMovie
            // 
            this.lblMovie.AutoSize = true;
            this.lblMovie.Location = new System.Drawing.Point(61, 184);
            this.lblMovie.Name = "lblMovie";
            this.lblMovie.Size = new System.Drawing.Size(93, 32);
            this.lblMovie.TabIndex = 1;
            this.lblMovie.Text = "Movie: ";
            // 
            // lblPrice
            // 
            this.lblPrice.AutoSize = true;
            this.lblPrice.Location = new System.Drawing.Point(61, 573);
            this.lblPrice.Name = "lblPrice";
            this.lblPrice.Size = new System.Drawing.Size(65, 32);
            this.lblPrice.TabIndex = 2;
            this.lblPrice.Text = "Price";
            // 
            // lblOutputPrice
            // 
            this.lblOutputPrice.Location = new System.Drawing.Point(371, 573);
            this.lblOutputPrice.Name = "lblOutputPrice";
            this.lblOutputPrice.Size = new System.Drawing.Size(106, 32);
            this.lblOutputPrice.TabIndex = 3;
            this.lblOutputPrice.Text = "..";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(249, 79);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(200, 39);
            this.textBox1.TabIndex = 4;
            // 
            // rdoBtnNoTimeToDie
            // 
            this.rdoBtnNoTimeToDie.AutoSize = true;
            this.rdoBtnNoTimeToDie.Location = new System.Drawing.Point(249, 184);
            this.rdoBtnNoTimeToDie.Name = "rdoBtnNoTimeToDie";
            this.rdoBtnNoTimeToDie.Size = new System.Drawing.Size(205, 36);
            this.rdoBtnNoTimeToDie.TabIndex = 5;
            this.rdoBtnNoTimeToDie.TabStop = true;
            this.rdoBtnNoTimeToDie.Text = "NoTime To Die";
            this.rdoBtnNoTimeToDie.UseVisualStyleBackColor = true;
            // 
            // rdoBtnTheFather
            // 
            this.rdoBtnTheFather.AutoSize = true;
            this.rdoBtnTheFather.Location = new System.Drawing.Point(249, 238);
            this.rdoBtnTheFather.Name = "rdoBtnTheFather";
            this.rdoBtnTheFather.Size = new System.Drawing.Size(158, 36);
            this.rdoBtnTheFather.TabIndex = 6;
            this.rdoBtnTheFather.TabStop = true;
            this.rdoBtnTheFather.Text = "The Father";
            this.rdoBtnTheFather.UseVisualStyleBackColor = true;
            // 
            // rdoBtnAnneFrank
            // 
            this.rdoBtnAnneFrank.AutoSize = true;
            this.rdoBtnAnneFrank.Location = new System.Drawing.Point(249, 296);
            this.rdoBtnAnneFrank.Name = "rdoBtnAnneFrank";
            this.rdoBtnAnneFrank.Size = new System.Drawing.Size(166, 36);
            this.rdoBtnAnneFrank.TabIndex = 7;
            this.rdoBtnAnneFrank.TabStop = true;
            this.rdoBtnAnneFrank.Text = "Anne Frank";
            this.rdoBtnAnneFrank.UseVisualStyleBackColor = true;
            // 
            // btnCalculatePrice
            // 
            this.btnCalculatePrice.Location = new System.Drawing.Point(179, 358);
            this.btnCalculatePrice.Name = "btnCalculatePrice";
            this.btnCalculatePrice.Size = new System.Drawing.Size(378, 68);
            this.btnCalculatePrice.TabIndex = 8;
            this.btnCalculatePrice.Text = "Calculate Price";
            this.btnCalculatePrice.UseVisualStyleBackColor = true;
            this.btnCalculatePrice.Click += new System.EventHandler(this.btnCalculatePrice_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(672, 668);
            this.Controls.Add(this.btnCalculatePrice);
            this.Controls.Add(this.rdoBtnAnneFrank);
            this.Controls.Add(this.rdoBtnTheFather);
            this.Controls.Add(this.rdoBtnNoTimeToDie);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.lblOutputPrice);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblMovie);
            this.Controls.Add(this.lblage);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblage;
        private System.Windows.Forms.Label lblMovie;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblOutputPrice;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.RadioButton rdoBtnNoTimeToDie;
        private System.Windows.Forms.RadioButton rdoBtnTheFather;
        private System.Windows.Forms.RadioButton rdoBtnAnneFrank;
        private System.Windows.Forms.Button btnCalculatePrice;
    }
}

