﻿using System;

namespace Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            //input from user for the first time
            Console.Write("Enter  a word: ");
            string inputWord = Console.ReadLine().ToLower();
            int countingTheVowel = 0;
            //processing
            while (inputWord != "stop")
            {
                
                // foreach letter in word using as hintinh otherwise forrach also can be used 
                for (int i = 0; i < inputWord.Length; i++)
                {
                    char c = inputWord[i];
                    if (c == 'a' || c == 'e' || c == 'i' || c == 'o'|| c=='u')
                    {
                        countingTheVowel++;
                    }
                    
                }
                //output 
                Console.WriteLine($"This word contains {countingTheVowel} Vowels.");
                
                // making the counting parameter 0
                countingTheVowel = 0;
                
                //for space
                Console.WriteLine();
                countingTheVowel = 0;
                
                //again asking for the user
                Console.Write("Enter  a word: ");
                inputWord = Console.ReadLine().ToLower();
            }
            Console.WriteLine();
            Console.WriteLine("End of the Program");

        }
    }
}
