﻿using System;

namespace Assignment3
{
    class Program
    {
        const int TotalNumber = 20;
        static void Main(string[] args)
        {
            //declaring array and random numbers 
            int[] numbers = new int[TotalNumber];
            Random generator = new Random();
            int sum = 0;

            //storing the value in array
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = generator.Next(1, 100);
                sum = sum + numbers[i];
            }

            //finding  the average and displaying it 
            int average = sum / numbers.Length;
            Console.WriteLine($"average value: {average}");

            //now checking each number to average 
            for (int i = 0; i < numbers.Length; i++)
            {
                if (numbers[i]>average)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                }
                else if (numbers[i] < average)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                }
                Console.Write($"{numbers[i]} ");
            }
            // for resetting the color and waiting for user
            Console.ResetColor();
            Console.ReadKey();   
        }
    }
}
