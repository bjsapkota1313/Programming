﻿using System;

namespace Assignment4
{
    class Program
    {
        //main method 
        static void Main(string[] args)
        {
            //using tracing number to count the no of perfect number
            int tracingNumber = 0;
            for (int i = 1; i <= 10000; i++)
            {
                int number = i;
                if (IsPerfectNumber(number))
                {
                    Console.WriteLine($"Perfect number {tracingNumber=tracingNumber+1} = {number} ");
                }
            }
        }
        //submethods
        static bool IsPerfectNumber(int number)
        {
            int sum = 0;
            for (int i = 1; i < number; i++)
            {
                if (number % i == 0)
                {
                    sum = sum + i;
                }
            }
            if (number == sum)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
