﻿using System;

namespace assignment7
{
    class Program
    {
        static void Main(string[] args)
        {
            string txt = null;
            Double minhealthyweight = 0;
            double maxhealthyweight = 0;


            //input from user
            Console.Write("Enter Weight (Kg): ");
            string inputweight = Console.ReadLine();
            Console.Write("Enter length (cm): ");
            string inputlength = Console.ReadLine();
            Console.Write("Enter Gender (Male/Female): ");
            string inputgender = Console.ReadLine().ToUpper();


            //converting string to intgers 
            double weight = double.Parse(inputweight);
            double length = double.Parse(inputlength);


            //processing the input
            double bmi = (weight * 10000) / (length * length);
            switch (inputgender)
            {
                case "MALE":

                    txt = "20..25";
                    minhealthyweight = (20 * length * length) / (10000) ;
                    maxhealthyweight = (25 * length * length) / (10000);
                    break;
                case "FEMALE":
                    txt = "19..24";
                    minhealthyweight = (19 * length * length) / (10000);
                    maxhealthyweight = (24 * length * length) / (10000);
                    break;
            }
            //outputing the process
            Console.WriteLine($"bmi value: {bmi:0.0}");
            Console.WriteLine($"normal bmi values (min .. max): {txt}");
            Console.WriteLine($"healthy weight range: {minhealthyweight:0.0} .. {maxhealthyweight:0.0}");
        }







            
        
    }
}




