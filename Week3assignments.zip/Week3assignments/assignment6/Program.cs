﻿using System;

namespace assignment6
{
    class Program
    {
        static void Main(string[] args)
        {
           //input from user 
            Console.Write("Enter a score: ");
            string input = Console.ReadLine();
            string txt = "";
            string txt2 = "";

            // converting string to integer 
            double inputscore = double.Parse(input);

            //processing 
            if (inputscore >=70)
            { txt = " course Passed"; 
            }
            else
            { txt = "Course not passed";
            }

            if (inputscore >=90 )
            { txt2 = "A"; 
            }
            else if (inputscore >=80 && inputscore<90 )
            { txt2 = "B"; 
            }
            else if (inputscore>=70 && inputscore < 80)
            { txt2 = "C";
            }
            else if (inputscore >=60 && inputscore < 70 )
                { txt2 = "D";
            }
            else
            { txt2 = "F";
            }

            //Displaying the output 
            Console.WriteLine($"Grade: {txt2}");
            Console.WriteLine($"{txt}");


        }
    }
}
