﻿using System;

namespace assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            int highestnumber = 0;
           int lowestnumber = 0;
           
            // input from user
            Console.Write("Enter first number:");
            string input =Console.ReadLine();
            Console.Write("Enter second Number:");
            String input2 = Console.ReadLine();
            

            // converting to numbers from string 
            int firstnumber = int.Parse(input);
            int secondnumber = int.Parse(input2);

            //calculation 
            if (firstnumber > secondnumber) 

            {   highestnumber = firstnumber;
                lowestnumber = secondnumber;
            }
            else
            {   highestnumber = secondnumber ;
                 lowestnumber = firstnumber ;
            }
            // Printing the answer 

            Console.WriteLine($"highest value is: { highestnumber}");
            
            Console.WriteLine($"lowest value is: { lowestnumber}");

        }
    }
}
