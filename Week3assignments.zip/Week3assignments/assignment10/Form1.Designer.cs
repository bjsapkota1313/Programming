﻿
namespace assignment10
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblage = new System.Windows.Forms.Label();
            this.lblprice = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtagebox = new System.Windows.Forms.TextBox();
            this.pricebtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblage
            // 
            this.lblage.AutoSize = true;
            this.lblage.Location = new System.Drawing.Point(-1, 94);
            this.lblage.Name = "lblage";
            this.lblage.Size = new System.Drawing.Size(61, 32);
            this.lblage.TabIndex = 0;
            this.lblage.Text = "Age:";
            // 
            // lblprice
            // 
            this.lblprice.AutoSize = true;
            this.lblprice.Location = new System.Drawing.Point(267, 372);
            this.lblprice.Name = "lblprice";
            this.lblprice.Size = new System.Drawing.Size(0, 32);
            this.lblprice.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 372);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Price ticket:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtagebox
            // 
            this.txtagebox.Location = new System.Drawing.Point(245, 94);
            this.txtagebox.Name = "txtagebox";
            this.txtagebox.Size = new System.Drawing.Size(200, 39);
            this.txtagebox.TabIndex = 3;
            this.txtagebox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // pricebtn
            // 
            this.pricebtn.Location = new System.Drawing.Point(12, 222);
            this.pricebtn.Name = "pricebtn";
            this.pricebtn.Size = new System.Drawing.Size(459, 58);
            this.pricebtn.TabIndex = 4;
            this.pricebtn.Text = "Calculate Price";
            this.pricebtn.UseVisualStyleBackColor = true;
            this.pricebtn.Click += new System.EventHandler(this.pricebtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 450);
            this.Controls.Add(this.pricebtn);
            this.Controls.Add(this.txtagebox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblprice);
            this.Controls.Add(this.lblage);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblage;
        private System.Windows.Forms.Label lblprice;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtagebox;
        private System.Windows.Forms.Button pricebtn;
    }
}

