﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment10
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pricebtn_Click(object sender, EventArgs e)
        {
            const int Price = 12;
            double outputprice = 0;
            //input from user 
            string input = txtagebox.Text;
            double age = double.Parse(input);

            //processing the input 
            if (age< 5)
            { outputprice = 0 * Price; 
            }
            else if (age >=5 && age<=12)
            { outputprice = 0.5 * Price; 
            }
            else if (age >=13 && age <=54)
            { outputprice = 1 * Price; 
            }
            else 
            { outputprice = 0 * Price; 
            }

            //displaying the output 
            lblprice.Text = outputprice.ToString("€ 0.00");


        }
    }
}
