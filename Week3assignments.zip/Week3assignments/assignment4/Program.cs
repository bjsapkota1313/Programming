﻿using System;

namespace assignment4
{
    class Program
    {
        static void Main(string[] args)
        {
           double highestnumber = 0;
           double lowestnumber = 0;
            //Lets input three numbers from user 
            Console.Write("Enter first number: ");
            string inputno1 = Console.ReadLine();
            Console.Write("Enter second number: ");
            string inputno2 = Console.ReadLine();
            Console.Write("Enter fthird number: ");
            string inputno3 = Console.ReadLine();

            //converting string input to integers
            double firstnumber = double.Parse(inputno1);
           double secondnumber = double.Parse(inputno2);
          double thirdnumber = double.Parse(inputno3);

            //calculating and processing 
            double sum = firstnumber + secondnumber + thirdnumber;
            double product = firstnumber * secondnumber * thirdnumber;
            double average = sum / 3;
            if (firstnumber > secondnumber && firstnumber > thirdnumber) { 
                 highestnumber = firstnumber; 
            }
           
            
            else if (secondnumber > firstnumber && secondnumber > thirdnumber)
            { 
                    highestnumber = secondnumber;
                }
                else
                {
                    highestnumber = thirdnumber;
                }
            

            if (firstnumber < secondnumber && firstnumber < thirdnumber)
            { highestnumber = firstnumber; }
          
            
             else if (secondnumber < firstnumber && secondnumber < thirdnumber)
                {
                    lowestnumber = secondnumber;
                }
                else
                {
                    lowestnumber = thirdnumber;
                }


            
            // Displaying the output
            Console.WriteLine($"Sum= {sum}");
            Console.WriteLine($"Average= {average: 0.00}");
            Console.WriteLine($"Product= {product}");
            Console.WriteLine($"highest= {highestnumber}");
            Console.WriteLine($"Lowest= {lowestnumber}");
        }
    }
}
