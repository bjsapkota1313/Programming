﻿
namespace assignment9
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lbloutput = new System.Windows.Forms.Label();
            this.lblfees = new System.Windows.Forms.Label();
            this.txtage = new System.Windows.Forms.TextBox();
            this.txtduration = new System.Windows.Forms.TextBox();
            this.radiobtnfootball = new System.Windows.Forms.RadioButton();
            this.radioBtnhandball = new System.Windows.Forms.RadioButton();
            this.btncalculate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(106, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sport:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(94, 229);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Age";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 305);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(246, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Membership duration";
            // 
            // lbloutput
            // 
            this.lbloutput.AutoSize = true;
            this.lbloutput.Location = new System.Drawing.Point(6, 496);
            this.lbloutput.Name = "lbloutput";
            this.lbloutput.Size = new System.Drawing.Size(176, 32);
            this.lbloutput.TabIndex = 3;
            this.lbloutput.Text = "Fees to be Paid";
            // 
            // lblfees
            // 
            this.lblfees.AutoSize = true;
            this.lblfees.Location = new System.Drawing.Point(359, 496);
            this.lblfees.Name = "lblfees";
            this.lblfees.Size = new System.Drawing.Size(0, 32);
            this.lblfees.TabIndex = 4;
            // 
            // txtage
            // 
            this.txtage.Location = new System.Drawing.Point(313, 229);
            this.txtage.Name = "txtage";
            this.txtage.Size = new System.Drawing.Size(200, 39);
            this.txtage.TabIndex = 5;
            // 
            // txtduration
            // 
            this.txtduration.Location = new System.Drawing.Point(313, 302);
            this.txtduration.Name = "txtduration";
            this.txtduration.Size = new System.Drawing.Size(200, 39);
            this.txtduration.TabIndex = 6;
            // 
            // radiobtnfootball
            // 
            this.radiobtnfootball.AutoSize = true;
            this.radiobtnfootball.Location = new System.Drawing.Point(293, 72);
            this.radiobtnfootball.Name = "radiobtnfootball";
            this.radiobtnfootball.Size = new System.Drawing.Size(131, 36);
            this.radiobtnfootball.TabIndex = 7;
            this.radiobtnfootball.TabStop = true;
            this.radiobtnfootball.Text = "Football";
            this.radiobtnfootball.UseVisualStyleBackColor = true;
            // 
            // radioBtnhandball
            // 
            this.radioBtnhandball.AutoSize = true;
            this.radioBtnhandball.Location = new System.Drawing.Point(293, 114);
            this.radioBtnhandball.Name = "radioBtnhandball";
            this.radioBtnhandball.Size = new System.Drawing.Size(140, 36);
            this.radioBtnhandball.TabIndex = 8;
            this.radioBtnhandball.TabStop = true;
            this.radioBtnhandball.Text = "Handball";
            this.radioBtnhandball.UseVisualStyleBackColor = true;
            this.radioBtnhandball.CheckedChanged += new System.EventHandler(this.radioBtnhandball_CheckedChanged);
            // 
            // btncalculate
            // 
            this.btncalculate.Location = new System.Drawing.Point(50, 392);
            this.btncalculate.Name = "btncalculate";
            this.btncalculate.Size = new System.Drawing.Size(407, 76);
            this.btncalculate.TabIndex = 9;
            this.btncalculate.Text = "Calculate Fee";
            this.btncalculate.UseVisualStyleBackColor = true;
            this.btncalculate.Click += new System.EventHandler(this.btncalculate_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 548);
            this.Controls.Add(this.btncalculate);
            this.Controls.Add(this.radioBtnhandball);
            this.Controls.Add(this.radiobtnfootball);
            this.Controls.Add(this.txtduration);
            this.Controls.Add(this.txtage);
            this.Controls.Add(this.lblfees);
            this.Controls.Add(this.lbloutput);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbloutput;
        private System.Windows.Forms.Label lblfees;
        private System.Windows.Forms.TextBox txtage;
        private System.Windows.Forms.TextBox txtduration;
        private System.Windows.Forms.RadioButton radiobtnfootball;
        private System.Windows.Forms.RadioButton radioBtnhandball;
        private System.Windows.Forms.Button btncalculate;
    }
}

