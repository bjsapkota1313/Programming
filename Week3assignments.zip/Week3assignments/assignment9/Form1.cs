﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

       
        private void radioBtnhandball_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void btncalculate_Click(object sender, EventArgs e)
        {
            //input from user 
            string inputage = txtage.Text;
            string inputduration = txtduration.Text;
            int memberFee;
            // converting string to integer
            int age = int.Parse(inputage);
            double duration = double.Parse(inputduration);
            if (radiobtnfootball.Checked)
            {
                memberFee = 175;
            }
            else
            {
                memberFee = 225;
            }

            if (age > 40)
            { memberFee = memberFee - 25; }
            else if  (duration > 10)
            { memberFee = memberFee - 20; }
            else
            { memberFee = memberFee; }

            // output
            lblfees.Text = memberFee.ToString("€ 0.00");

        }
    }
}
