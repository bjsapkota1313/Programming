﻿using System;

namespace assignment5
{
    class Program
    {
        static void Main(string[] args)
        {
            string txt = "";
            //asking the number from user
            Console.Write("Enter first number: ");
            string inputnumber1 = Console.ReadLine();
            Console.Write("Enter second number: ");
            string inputnumber2 = Console.ReadLine();

            //converting it to integer
            double firstnumber = double.Parse(inputnumber1);
            double secondnumber = double.Parse(inputnumber2);
            double reaminder1 = firstnumber % secondnumber;
            double remainder2 = secondnumber % firstnumber;

            // processing the input 
            if (reaminder1 == 0) 
            { txt = " number 1 is multiple of number 2 "; 
            } 
            else if (remainder2 ==0)
            { txt = "number 2 is multiple of number 1 "; 
            }
            else
            { txt = "Numbers are no multiples"; }

            //output 
            Console.WriteLine($"{txt}");

                

        }
    }
}
