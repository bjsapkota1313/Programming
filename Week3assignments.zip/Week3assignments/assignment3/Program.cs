﻿using System;

namespace assignment3
{
    class Program
    {
        static void Main(string[] args)
        {

            string txt = ""; 
                //input from the user 
            Console.Write("Enter first number:");
            string inputnumber1 = Console.ReadLine();
            Console.Write("Enter second number:");
            string inputnumber2 = Console.ReadLine();
            Console.Write("Enter third number:");
            string inputnumber3 = Console.ReadLine();

            // converting the string into integers
            int firstnumber = int.Parse(inputnumber1);
            int secondnumber = int.Parse(inputnumber2);
            int thirdnumber = int.Parse(inputnumber3);

            //processing and displaying the result 
            if (firstnumber > thirdnumber && secondnumber > thirdnumber)
            { txt = "The third number is the smallest of the three"; }
            else
            { txt = "The third number is not the smallest of the three"; }

            //Displaying the output
            Console.WriteLine($"{txt}");


        }
    }
}
