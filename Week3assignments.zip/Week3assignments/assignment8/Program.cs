﻿using System;

namespace assignment8
{
    class Program
    {
        static void Main(string[] args)
        {
            //input from the user 
            Console.Write("Enter numbers of working hours: ");
            string inputhours = Console.ReadLine();
            Console.Write("Enter numbers of Years: ");
            string inputyears = Console.ReadLine(); 
            Console.Write("Enter numbers of failures: ");
            string inputnooffailures = Console.ReadLine();



            //converting the input 
            double noofworkinghours = double.Parse(inputhours);
            double noofyears = double.Parse(inputyears);
            int nooffaliures = int.Parse(inputnooffailures);
            string txt = "";

            //processing the input 
            if (noofworkinghours>10000 | noofyears>=7 | nooffaliures>25)
            { txt ="Machine needs to be replaced."; 
            }
            else
            { txt ="Machine does not to be replaced."; 
            }
            //displaying the process 
            Console.WriteLine($" {txt}");
        }
    }
}
