﻿using System;

namespace assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            //input from the user 
            Console.Write("Enter a number (1..4):");
            string input = Console.ReadLine();
            int inputnumber = int.Parse(input);
            string txt = null;

            // Processing the input 
            switch (inputnumber)
            {
                case 1:
                    txt = "clubs";
                    break;
                case 2:
                    txt = "diamonds";
                    break;
                case 3:
                    txt = "hearts";
                    break;
                case 4:
                    txt = "spades";
                    break;
                default:
                    txt = "Incorrect number!";
                    break;
            }

                    //output
                  Console.Write($"{txt}");

            


        }
    }
}
