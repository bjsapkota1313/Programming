﻿using System;

namespace assignment2
{
    class Program
    {
        static void Main(string[] args)
        {

            //inputting the number from user
            Console.Write("Enter target number: ");
            int targetNumber = int.Parse(Console.ReadLine());
            int countNumber = 0;
            Console.Write("Enter a number: ");
            int inputNumber = int.Parse(Console.ReadLine());

            while (inputNumber != 0)
            {
                if (inputNumber == targetNumber)
                { countNumber++; }
                //again asking for user to input the number
                Console.Write("Enter a number: ");
                inputNumber = int.Parse(Console.ReadLine());
            }
            //output
            Console.WriteLine($"Count of numbers equal to target number: {countNumber}");
            Console.ReadKey();

         }   
    }
}
