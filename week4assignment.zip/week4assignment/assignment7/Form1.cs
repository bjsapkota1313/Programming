﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btncalculate_Click(object sender, EventArgs e)
        {
            int sidesOfSquare = int.Parse(txtInputSide.Text);
            string output = "";


            for (int i = 0; i < sidesOfSquare; i++) //for rows
            { for (int j = 0; j < sidesOfSquare; j++)//for columns
                { if (i == 0 || i==sidesOfSquare-1)
                    { output += "X"; }
                    else if (j == 0 || j==sidesOfSquare-1)
                    { output += "X"; }
                    else
                    { output += " "; }

                }
                output += "\n";
                lbloutput.Text = output;





            }
        }
    }
}
