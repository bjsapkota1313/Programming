﻿using System;

namespace assignment5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a year: ");
            int inputYear = int.Parse(Console.ReadLine());
            while (inputYear != 0)
            {
                if (inputYear<0)
                { Console.WriteLine("Year must be positive! "); }
                
                else if (inputYear % 400 == 0 )
                { Console.WriteLine($"{inputYear} is a leap year."); }



                else if (inputYear % 4 == 0 && inputYear % 100 != 0)
                { Console.WriteLine($"{inputYear} is a leap year"); }
                else  { Console.WriteLine($"{inputYear} is not a leap year."); } 

                Console.Write("Enter a year: ");
                inputYear = int.Parse(Console.ReadLine());


            }           
        }
    }
}
