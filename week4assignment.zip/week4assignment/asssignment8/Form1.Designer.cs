﻿
namespace asssignment8
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lbl = new System.Windows.Forms.Label();
            this.btncompare = new System.Windows.Forms.Button();
            this.lbl2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblsumoutput1 = new System.Windows.Forms.Label();
            this.lblsumoutput = new System.Windows.Forms.Label();
            this.lblOutputmessage = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(349, 91);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(200, 39);
            this.textBox1.TabIndex = 0;
            // 
            // lbl
            // 
            this.lbl.AutoSize = true;
            this.lbl.Location = new System.Drawing.Point(26, 91);
            this.lbl.Name = "lbl";
            this.lbl.Size = new System.Drawing.Size(214, 32);
            this.lbl.TabIndex = 1;
            this.lbl.Text = "Enter a number (n)";
            // 
            // btncompare
            // 
            this.btncompare.Location = new System.Drawing.Point(26, 182);
            this.btncompare.Name = "btncompare";
            this.btncompare.Size = new System.Drawing.Size(532, 66);
            this.btncompare.TabIndex = 2;
            this.btncompare.Text = "Compare";
            this.btncompare.UseVisualStyleBackColor = true;
            this.btncompare.Click += new System.EventHandler(this.btncompare_Click);
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Location = new System.Drawing.Point(35, 346);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(178, 32);
            this.lbl2.TabIndex = 3;
            this.lbl2.Text = "sum=1+2+...+n";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 406);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(178, 32);
            this.label3.TabIndex = 4;
            this.label3.Text = "sum=n*(n+1)/2";
            // 
            // lblsumoutput1
            // 
            this.lblsumoutput1.AutoSize = true;
            this.lblsumoutput1.Location = new System.Drawing.Point(417, 346);
            this.lblsumoutput1.Name = "lblsumoutput1";
            this.lblsumoutput1.Size = new System.Drawing.Size(0, 32);
            this.lblsumoutput1.TabIndex = 5;
            // 
            // lblsumoutput
            // 
            this.lblsumoutput.AutoSize = true;
            this.lblsumoutput.Location = new System.Drawing.Point(417, 406);
            this.lblsumoutput.Name = "lblsumoutput";
            this.lblsumoutput.Size = new System.Drawing.Size(0, 32);
            this.lblsumoutput.TabIndex = 6;
            // 
            // lblOutputmessage
            // 
            this.lblOutputmessage.Location = new System.Drawing.Point(73, 502);
            this.lblOutputmessage.Name = "lblOutputmessage";
            this.lblOutputmessage.Size = new System.Drawing.Size(426, 46);
            this.lblOutputmessage.TabIndex = 7;
            this.lblOutputmessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(646, 594);
            this.Controls.Add(this.lblOutputmessage);
            this.Controls.Add(this.lblsumoutput);
            this.Controls.Add(this.lblsumoutput1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.btncompare);
            this.Controls.Add(this.lbl);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lbl;
        private System.Windows.Forms.Button btncompare;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblsumoutput1;
        private System.Windows.Forms.Label lblsumoutput;
        private System.Windows.Forms.Label lblOutputmessage;
    }
}

