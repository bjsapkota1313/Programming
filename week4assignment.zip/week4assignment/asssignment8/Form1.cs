﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace asssignment8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btncompare_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text;
            int inputNumber = int.Parse(input);
            int sum = 0;
            int anotherSum = 0;
           for (int loopingnumber=0; loopingnumber<=inputNumber; loopingnumber++)
            { sum = sum + loopingnumber; }
            anotherSum = inputNumber * (inputNumber + 1) / 2;
            if (sum==anotherSum)
            { lblOutputmessage.Text = "The sum and formula are equal."; }   
            else
            { lblOutputmessage.Text = "The sum and formula are not equal."; }
            lblsumoutput.Text = sum.ToString();
            lblsumoutput1.Text = anotherSum.ToString();



        }
    }
}
