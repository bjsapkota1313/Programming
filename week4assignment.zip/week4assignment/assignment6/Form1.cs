﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Click(object sender, EventArgs e)
        {
            const double  InterestRate = 0.05;
            //input on textbox
            String input = txtinputbox.Text;
            double startAmount = double.Parse(input);
            int countingYear = 0;
            double finalCapital = 0;

            // calculation 
            while (countingYear<5)
            {  finalCapital =  startAmount+startAmount * InterestRate;
                startAmount = finalCapital;
                countingYear++;
               

            }

            lblOutput.Text = startAmount.ToString("€0.00");
        }
    }
}
