﻿using System;

namespace assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            int countingNumber = 0;
            int sum = 0;
            Console.Write("Enter a number: ");
            int inputNumber = int.Parse(Console.ReadLine());

            while (inputNumber != 0) 

            {
                countingNumber++;
                if (countingNumber % 5 == 0)
                {
                    sum = sum + inputNumber;
                }
                
                Console.Write("Enter a number: ");
                inputNumber = int.Parse(Console.ReadLine());
            }

                //output 
            Console.WriteLine($"Sum of 5th, 10th, 15th, ... number is: {sum}");
            Console.ReadKey();

        }
    }
}
