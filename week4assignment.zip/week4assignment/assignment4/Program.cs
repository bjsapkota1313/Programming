﻿using System;

namespace assignment4
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int number1 =0;
            int number2 = 1;
            int sum = 0;

            for (int loopingNumber = 0; loopingNumber < 19; loopingNumber++)
            {


                sum = number1 + number2;
                if (sum < 2)
                {
                    Console.Write($"1, 1, ");
                    number1 = number2;
                    number2 = sum;

                }


                else if (loopingNumber == 18)
                {
                    Console.Write($"{sum} ");
                    number1 = number2;
                    number2 = sum;


                }
                else
                {
                    Console.Write($"{sum}, ");
                    number1 = number2;
                    number2 = sum;
                }

            }
            Console.ReadKey();








            



        }
    }
}
