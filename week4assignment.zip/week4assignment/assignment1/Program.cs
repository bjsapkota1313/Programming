﻿using System;

namespace assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            //input from the user
            Console.Write("Enter a number: ");
            int inputNumber = int.Parse(Console.ReadLine());
            double sum = 0;
            double average = 0;
            int count = 0;

            // using while loop
            while (inputNumber!=0)
            { if (inputNumber>0)
                { sum = sum + inputNumber;
                    count++;
                }
                Console.Write("Enter a number: ");
                inputNumber = int.Parse(Console.ReadLine());

            }
            // checking if user inputs the 0
            if (sum >0)
            { average = sum /count ; }
            else
            { average = 0; }

            //output 
            Console.WriteLine($"Average of all positive numbers is: {average:0.00}");
            Console.ReadKey();



        }
    }
}
