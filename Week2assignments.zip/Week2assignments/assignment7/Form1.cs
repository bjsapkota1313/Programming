﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            const  double Vatrate = 0.21;
            // calculating
            string input = txts.Text;
            double start = double.Parse(input);
            string input1 = txtend.Text;
            double end = double.Parse(input1);
            string input3 = txtprx.Text;
            double price = double.Parse(input3);


            //calculating
            double price1 = (end - start) * price;
            double vatamt = price1 * Vatrate ;
            double pricecvat = price1 + vatamt;

            // displaying 
            txtexclvat.Text = price1.ToString("0.00");
            txtincvat.Text = pricecvat.ToString("0.00");
            txtvat.Text = vatamt.ToString("0.00");



        }

        private void txtexclvat_TextChanged(object sender, EventArgs e)
        {

        }

        private void erasebutton_Click(object sender, EventArgs e)
        {
            txts.Text = "";
            txtend.Text = "";
            txtprx.Text = "";
            txtexclvat.Text = "";
            txtincvat.Text = "";
            txtvat.Text = "";






        }
    }
}
