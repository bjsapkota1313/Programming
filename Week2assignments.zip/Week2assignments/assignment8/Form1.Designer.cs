﻿
namespace assignment8
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txttshirt = new System.Windows.Forms.TextBox();
            this.txtjeans = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Invoice = new System.Windows.Forms.GroupBox();
            this.txttotal = new System.Windows.Forms.Label();
            this.txtvat = new System.Windows.Forms.Label();
            this.txtprice = new System.Windows.Forms.Label();
            this.txtdate = new System.Windows.Forms.Label();
            this.Invoice.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(75, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(309, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Numbers of Tshirts(*€30.00)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(75, 178);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(313, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "Numbers of Jeans(*€100.00)";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(88, 508);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Date:";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // txttshirt
            // 
            this.txttshirt.Location = new System.Drawing.Point(415, 130);
            this.txttshirt.Name = "txttshirt";
            this.txttshirt.Size = new System.Drawing.Size(200, 39);
            this.txttshirt.TabIndex = 3;
            // 
            // txtjeans
            // 
            this.txtjeans.Location = new System.Drawing.Point(415, 178);
            this.txtjeans.Name = "txtjeans";
            this.txtjeans.Size = new System.Drawing.Size(200, 39);
            this.txtjeans.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(75, 274);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(540, 122);
            this.button1.TabIndex = 5;
            this.button1.Text = "Calculate";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(76, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 32);
            this.label4.TabIndex = 6;
            this.label4.Text = "Price:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(76, 100);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 32);
            this.label5.TabIndex = 7;
            this.label5.Text = "VAT";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(76, 132);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(122, 32);
            this.label6.TabIndex = 8;
            this.label6.Text = "Totalprice:";
            // 
            // Invoice
            // 
            this.Invoice.Controls.Add(this.label6);
            this.Invoice.Controls.Add(this.txttotal);
            this.Invoice.Controls.Add(this.label5);
            this.Invoice.Controls.Add(this.txtvat);
            this.Invoice.Controls.Add(this.label4);
            this.Invoice.Controls.Add(this.txtprice);
            this.Invoice.Controls.Add(this.txtdate);
            this.Invoice.Location = new System.Drawing.Point(12, 472);
            this.Invoice.Name = "Invoice";
            this.Invoice.Size = new System.Drawing.Size(634, 246);
            this.Invoice.TabIndex = 13;
            this.Invoice.TabStop = false;
            this.Invoice.Text = "Invoice";
            this.Invoice.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txttotal
            // 
            this.txttotal.AutoSize = true;
            this.txttotal.Location = new System.Drawing.Point(403, 132);
            this.txttotal.Name = "txttotal";
            this.txttotal.Size = new System.Drawing.Size(0, 32);
            this.txttotal.TabIndex = 3;
            // 
            // txtvat
            // 
            this.txtvat.AutoSize = true;
            this.txtvat.Location = new System.Drawing.Point(403, 100);
            this.txtvat.Name = "txtvat";
            this.txtvat.Size = new System.Drawing.Size(0, 32);
            this.txtvat.TabIndex = 2;
            this.txtvat.Click += new System.EventHandler(this.label7_Click);
            // 
            // txtprice
            // 
            this.txtprice.AutoSize = true;
            this.txtprice.Location = new System.Drawing.Point(403, 68);
            this.txtprice.Name = "txtprice";
            this.txtprice.Size = new System.Drawing.Size(0, 32);
            this.txtprice.TabIndex = 1;
            // 
            // txtdate
            // 
            this.txtdate.AutoSize = true;
            this.txtdate.Location = new System.Drawing.Point(403, 36);
            this.txtdate.Name = "txtdate";
            this.txtdate.Size = new System.Drawing.Size(0, 32);
            this.txtdate.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(658, 730);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtjeans);
            this.Controls.Add(this.txttshirt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Invoice);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Invoice.ResumeLayout(false);
            this.Invoice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txttshirt;
        private System.Windows.Forms.TextBox txtjeans;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox Invoice;
        private System.Windows.Forms.Label txtvat;
        private System.Windows.Forms.Label txtprice;
        private System.Windows.Forms.Label txtdate;
        private System.Windows.Forms.Label txttotal;
    }
}

