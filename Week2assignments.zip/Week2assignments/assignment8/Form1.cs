﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            const double Vatrate = 0.21;
            string input = txtjeans.Text;
            int noofjeans = int.Parse(input);
            string input2 = txttshirt.Text;
            int nooftshirt = int.Parse(input2);

            //calculation 
            double priceofjeans = noofjeans * 100.00;
            double priceoftshirt = nooftshirt * 30.00;
            double sum = priceofjeans + priceoftshirt;
            double vatamt = sum * Vatrate;
            Double totalamt = sum + vatamt;

            // displaying 
            txtvat.Text = vatamt.ToString("€ 0.00");
            txtprice.Text = sum.ToString(" € 0.00");
            txttotal.Text = totalamt.ToString("€ 0.00");
            txtdate.Text = DateTime.Now.ToString("hh:MM:ss dd/mm/yyyy");
            



        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
