﻿using System;

namespace bj1
{
    class Program
    {
        static void Main(string[] args)
        { //asking user the amount of seconds 
            Console.Write("Enter number of seconds: ");
            string input = Console.ReadLine();
            int seconds = int.Parse(input);

            //calculating 

            int hrs = seconds / 3600;
            int min = (seconds % 3600) / 60;
            int sec = seconds % 60;
            //displaying 


            Console.WriteLine($"{hrs:00}:{min:00}:{sec:00} ");
            Console.ReadKey();
        }
    }
}
