﻿using System;

namespace assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            //input from the user and converting them to string
            Console.Write("Enter your 1st number: ");
            String input = Console.ReadLine();
            double firstno = double.Parse(input);
            Console.Write("enter your 2nd number: ");
            String input2 = Console.ReadLine();
            double secondno = double.Parse(input2);
            Console.Write("enter your 3rd number: ");
            String input3 = Console.ReadLine();
            
            //calculating
            double thirdno = double.Parse(input3);
            double sum = (firstno + secondno + thirdno);
            double avgno = sum / 3;
            
            //output
            Console.WriteLine($"The average is: {avgno}");
            Console.ReadKey();
        }
    }
}
