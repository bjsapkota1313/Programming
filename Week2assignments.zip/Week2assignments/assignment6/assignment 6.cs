﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btncal_Click(object sender, EventArgs e)
        {
            { //asking user the amount of seconds 

                string input = txtsec.Text;
                int seconds = int.Parse(input);

                //calculating 

                int hrs = seconds / 3600;
                int min = (seconds % 3600) / 60;
                int sec = seconds % 60;
                //displaying 


                txthrs.Text = $"{hrs:00}:{min:00}:{sec:00}";
                
            }    }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }
    }
}
