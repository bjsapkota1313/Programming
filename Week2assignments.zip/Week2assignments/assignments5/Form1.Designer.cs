﻿
namespace assignments5
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Number1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Number2 = new System.Windows.Forms.Label();
            this.txtno1 = new System.Windows.Forms.TextBox();
            this.txtno2 = new System.Windows.Forms.TextBox();
            this.txtno3 = new System.Windows.Forms.TextBox();
            this.btnavg = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtavg = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Number1
            // 
            this.Number1.AutoSize = true;
            this.Number1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Number1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Number1.Location = new System.Drawing.Point(104, 115);
            this.Number1.Name = "Number1";
            this.Number1.Size = new System.Drawing.Size(161, 45);
            this.Number1.TabIndex = 0;
            this.Number1.Text = "Number1:";
            this.Number1.Click += new System.EventHandler(this.Number1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label2.Location = new System.Drawing.Point(104, 205);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(161, 45);
            this.label2.TabIndex = 1;
            this.label2.Text = "Number3:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // Number2
            // 
            this.Number2.AutoSize = true;
            this.Number2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Number2.ForeColor = System.Drawing.Color.Black;
            this.Number2.Location = new System.Drawing.Point(104, 160);
            this.Number2.Name = "Number2";
            this.Number2.Size = new System.Drawing.Size(161, 45);
            this.Number2.TabIndex = 2;
            this.Number2.Text = "Number2:";
            this.Number2.Click += new System.EventHandler(this.label3_Click);
            // 
            // txtno1
            // 
            this.txtno1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtno1.Location = new System.Drawing.Point(451, 121);
            this.txtno1.Name = "txtno1";
            this.txtno1.Size = new System.Drawing.Size(200, 50);
            this.txtno1.TabIndex = 3;
            this.txtno1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtno2
            // 
            this.txtno2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtno2.Location = new System.Drawing.Point(451, 166);
            this.txtno2.Name = "txtno2";
            this.txtno2.Size = new System.Drawing.Size(200, 50);
            this.txtno2.TabIndex = 4;
            // 
            // txtno3
            // 
            this.txtno3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtno3.Location = new System.Drawing.Point(451, 212);
            this.txtno3.Name = "txtno3";
            this.txtno3.Size = new System.Drawing.Size(200, 50);
            this.txtno3.TabIndex = 5;
            // 
            // btnavg
            // 
            this.btnavg.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnavg.Location = new System.Drawing.Point(51, 314);
            this.btnavg.Name = "btnavg";
            this.btnavg.Size = new System.Drawing.Size(736, 56);
            this.btnavg.TabIndex = 7;
            this.btnavg.Text = "Calculate average";
            this.btnavg.UseVisualStyleBackColor = true;
            this.btnavg.Click += new System.EventHandler(this.btnavg_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 470);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 32);
            this.label1.TabIndex = 8;
            this.label1.Text = "Average:";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtavg
            // 
            this.txtavg.AutoSize = true;
            this.txtavg.Location = new System.Drawing.Point(610, 470);
            this.txtavg.Name = "txtavg";
            this.txtavg.Size = new System.Drawing.Size(0, 32);
            this.txtavg.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1040, 604);
            this.Controls.Add(this.txtavg);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnavg);
            this.Controls.Add(this.txtno3);
            this.Controls.Add(this.txtno2);
            this.Controls.Add(this.txtno1);
            this.Controls.Add(this.Number2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Number1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Number1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Number2;
        private System.Windows.Forms.TextBox txtno1;
        private System.Windows.Forms.TextBox txtno2;
        private System.Windows.Forms.TextBox txtno3;
        private System.Windows.Forms.Button btnavg;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label txtavg;
    }
}

