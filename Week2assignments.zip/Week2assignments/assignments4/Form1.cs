﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignments4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Determinevat_Click(object sender, EventArgs e)
        {
            const double Vat = 0.21;
           

            String input = pricebox.Text;
            double pc = double.Parse(input);
            double totalvat = pc * Vat;
            double totaal = totalvat + pc;

            pricebox1.Text = pc.ToString("0.00");
            vatbox.Text = totalvat.ToString("0.00");
            totalbox.Text = totaal.ToString("0.00");

       





        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pricebox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
