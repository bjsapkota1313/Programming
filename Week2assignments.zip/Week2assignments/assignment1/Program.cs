﻿using System;
using System.Globalization;
using System.Threading;

namespace assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            const double Vat = 0.21;

            //setting program culture
            CultureInfo ci = new CultureInfo("en-US");

            Thread.CurrentThread.CurrentUICulture = ci;
            Thread.CurrentThread.CurrentCulture = ci;
            Console.Write("price ");

            String input = Console.ReadLine();
            
            //converting the input
            double pc = double.Parse(input);

            //calculating
            double totalvat = pc * Vat;
            double totaal = totalvat + pc;

            //output
            Console.WriteLine($"price: {pc:0.00}, vat: {totalvat:0.00}, total: {totaal:0.00}");
            Console.ReadKey();

        }
    }
}
