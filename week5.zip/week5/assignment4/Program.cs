﻿using System;

namespace assignment4
{
    class Program
    {
        static void Main(string[] args)
        {
            const int numbersOfArrays = 20;
            int[] numbers = new int[numbersOfArrays];

            // using to read the value from user
           
            int i = 0;
            int inputNumber = 1;
            while (i < numbers.Length && inputNumber != 0)

            {
                
                
                    Console.Write("Enter a number (0=stop): ");
                    inputNumber = int.Parse(Console.ReadLine());
                    numbers[i] = inputNumber;
                i++;
                
            }
            Console.WriteLine();

            //asking user the search value 
            Console.Write($"Enter a search value: ");
            int searchValue = int.Parse(Console.ReadLine());
            Console.WriteLine();

            // using looping to check the search value in occerance 
            int countingTheOccurance = 0;
            for (int j = 0; j < numbers.Length; j++)
            {
                if (searchValue == numbers[j])
                { countingTheOccurance = countingTheOccurance + 1; }
            }
            Console.WriteLine();

            //giving the output of occurance 
            Console.WriteLine($"Number of occurences of searchvalue ({searchValue}) is: {countingTheOccurance}");
            Console.ReadKey();


















        }
    }
}
