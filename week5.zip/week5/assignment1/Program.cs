﻿using System;

namespace assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            const int InputNumber = 20;
            int[] numbers = new int[InputNumber];
            Random randomNumbers = new Random();
            //for filling the numbers and displaying them 
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = randomNumbers.Next(201);
                Console.WriteLine($"Element {i} is {numbers[i]}");
            }
            Console.WriteLine();
            //determing the average
            double sum = 0;
            double average = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                sum = sum + numbers[i];
            }
            average = sum / numbers.Length;

            //displaying the average now
            Console.WriteLine($"The average is: {average:0.00}");

            Console.WriteLine();

            //displaying the difference betn the numbers and average
            double difference = 0;
            for (int i = 0; i < numbers.Length; i++)
            {
                difference = average - numbers[i];
                difference = Math.Abs(difference);
                Console.WriteLine($"Difference between average and element {i} is {difference:0.00}");
            }

            Console.ReadKey();
        }
    }
}
