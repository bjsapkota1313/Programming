﻿
namespace assignment7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbloutput = new System.Windows.Forms.Label();
            this.btnthrow = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbloutput
            // 
            this.lbloutput.Location = new System.Drawing.Point(12, 74);
            this.lbloutput.Name = "lbloutput";
            this.lbloutput.Size = new System.Drawing.Size(749, 218);
            this.lbloutput.TabIndex = 0;
            this.lbloutput.Text = "label1";
            // 
            // btnthrow
            // 
            this.btnthrow.Location = new System.Drawing.Point(201, 372);
            this.btnthrow.Name = "btnthrow";
            this.btnthrow.Size = new System.Drawing.Size(304, 46);
            this.btnthrow.TabIndex = 1;
            this.btnthrow.Text = "Throw";
            this.btnthrow.UseVisualStyleBackColor = true;
            this.btnthrow.Click += new System.EventHandler(this.btnthrow_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnthrow);
            this.Controls.Add(this.lbloutput);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbloutput;
        private System.Windows.Forms.Button btnthrow;
    }
}

