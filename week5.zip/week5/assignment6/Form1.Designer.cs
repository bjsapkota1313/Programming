﻿
namespace assignment6
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblTablebefore = new System.Windows.Forms.Label();
            this.lbltableafter = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtComprasionNo = new System.Windows.Forms.TextBox();
            this.btnCompare = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Segoe UI Emoji", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(6, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(407, 64);
            this.label1.TabIndex = 0;
            this.label1.Text = "Content table (before)";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Segoe UI Emoji", 13.875F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(445, 62);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(400, 64);
            this.label2.TabIndex = 1;
            this.label2.Text = "Content table (after)";
            // 
            // lblTablebefore
            // 
            this.lblTablebefore.Location = new System.Drawing.Point(6, 126);
            this.lblTablebefore.Name = "lblTablebefore";
            this.lblTablebefore.Size = new System.Drawing.Size(407, 656);
            this.lblTablebefore.TabIndex = 2;
            // 
            // lbltableafter
            // 
            this.lbltableafter.Location = new System.Drawing.Point(445, 126);
            this.lbltableafter.Name = "lbltableafter";
            this.lbltableafter.Size = new System.Drawing.Size(375, 672);
            this.lbltableafter.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(6, 821);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(238, 64);
            this.label5.TabIndex = 4;
            this.label5.Text = "comprasion number";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(529, 840);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 32);
            this.label6.TabIndex = 5;
            // 
            // txtComprasionNo
            // 
            this.txtComprasionNo.Location = new System.Drawing.Point(265, 818);
            this.txtComprasionNo.Name = "txtComprasionNo";
            this.txtComprasionNo.Size = new System.Drawing.Size(200, 39);
            this.txtComprasionNo.TabIndex = 6;
            // 
            // btnCompare
            // 
            this.btnCompare.Location = new System.Drawing.Point(572, 811);
            this.btnCompare.Name = "btnCompare";
            this.btnCompare.Size = new System.Drawing.Size(150, 46);
            this.btnCompare.TabIndex = 7;
            this.btnCompare.Text = "Compare";
            this.btnCompare.UseVisualStyleBackColor = true;
            this.btnCompare.Click += new System.EventHandler(this.btnCompare_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(13F, 32F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(832, 890);
            this.Controls.Add(this.btnCompare);
            this.Controls.Add(this.txtComprasionNo);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lbltableafter);
            this.Controls.Add(this.lblTablebefore);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblTablebefore;
        private System.Windows.Forms.Label lbltableafter;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtComprasionNo;
        private System.Windows.Forms.Button btnCompare;
    }
}

