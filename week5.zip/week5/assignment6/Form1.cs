﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace assignment6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        const int totalNumbers = 20;
        int[] numbers = new int[totalNumbers];
        private void Form1_Load(object sender, EventArgs e)
        {
            
            Random randomNumbers = new Random();
            lblTablebefore.Text = "";
            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = randomNumbers.Next(500);
                lblTablebefore.Text += ($"Element {i:00} = {numbers[i].ToString()} \n");
            }

        }

        private void btnCompare_Click(object sender, EventArgs e)
        {
            //input of comparsion from user
            string input = txtComprasionNo.Text;
            int comparisonNumber = int.Parse(input);
            int newNumber = 0;

            for (int i = 0; i < totalNumbers; i++)
            {
                if (numbers[i] >= comparisonNumber)
                { newNumber = numbers[i] + 10; }
                else
                { newNumber = numbers[i] - 5; }

                //to output 
                lbltableafter.Text += ($"Element {i:00} = {newNumber.ToString()} \n");

            }
            btnCompare.Enabled = false;


        }

      
    }
}
