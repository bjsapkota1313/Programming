﻿using System;

namespace assignment3
{
    class Program
    {
        static void Main(string[] args)
        {

            //input the course and the numbers of student from the user 
            Console.Write("Enter course name: ");
            string courseName = Console.ReadLine();
            Console.Write("Enter number of students: ");
            int numbersofStudent = int.Parse(Console.ReadLine());
            Console.WriteLine();

            // using array for name of students
            string[] studentName = new string[numbersofStudent];
            for (int i = 0; i < studentName.Length; i++)
            {
                
                Console.Write($"Enter name of student {i+1}: ");
                studentName[i] = Console.ReadLine();

            }
            Console.WriteLine();

            //using another for the marks of the student and taking out the sum 
            double sumOfMarks = 0;
            int[] studentMarks = new int[numbersofStudent];
            for (int j = 0; j <studentName.Length; j++)
            {
                Console.Write($"Enter grade of {studentName[j]}: ");
                studentMarks[j] = int.Parse(Console.ReadLine());
                sumOfMarks = sumOfMarks + studentMarks[j];
            }
            Console.WriteLine();

            //finding the average 
            double averageGrade = sumOfMarks / studentName.Length;
            Console.WriteLine($"Average grade: {averageGrade:0.0}");

            //finding the highest
           
            int highest = -1;
            string highestName = "";
            for (int k = 0; k < studentMarks.Length; k++)
            {
                if (highest < studentMarks[k])
                {
                    highest = studentMarks[k];
                    highestName = studentName[k];
                }
            }
            //printing the highest
            Console.WriteLine($" student {highestName} has maximum grade: {highest}");

            //printing everything
            Console.WriteLine();
            for (int k = 0; k < studentName.Length; k++)
            { Console.WriteLine($"Grade for student {studentName[k]} (course {courseName}): {studentMarks[k]} "); }

        }
    }
}
