﻿using System;

namespace assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            const int NumbersLength = 20;
            //assigning value for array
            int[] numbers = new int[NumbersLength];
            Random inputNumbers = new Random();

            for (int i = 0; i < numbers.Length; i++)
            {
                numbers[i] = inputNumbers.Next(150);
                Console.WriteLine($"Element {i} = {numbers[i]}");
            }
            Console.WriteLine();

            // for smallest and number of occerance of small number 
            int smallest= 150;

            for (int j = 0; j < numbers.Length; j++)
            {

                if (numbers[j] < smallest)
                { smallest = numbers[j]; }
            }

            // using another loop too check the occurence
            int countingNumber = 0;
            for (int k = 0; k < numbers.Length; k++)
            {
                if (smallest == numbers[k])
                {
                    countingNumber++;
                }


            }
            Console.WriteLine($"smallest number = {smallest}");
            Console.WriteLine($"number of occurence = {countingNumber}");






        }
    }
}
